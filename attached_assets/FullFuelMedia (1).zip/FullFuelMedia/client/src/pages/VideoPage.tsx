import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Play, Clock, Calendar, Eye } from 'lucide-react';
import VideoPlayer from '@/components/ui/player';
import { Video } from '@shared/schema';

const VideoPage = () => {
  const [location] = useLocation();
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  
  // Get video ID from URL if present
  const videoId = location.split('/').pop();
  const isDetailView = videoId && !isNaN(Number(videoId));
  
  // Fetch all videos
  const { data: videos, isLoading: allVideosLoading, error: allVideosError } = useQuery({
    queryKey: ['/api/videos'],
  });
  
  // Fetch specific video if in detail view
  const { data: videoDetail, isLoading: videoDetailLoading, error: videoDetailError } = useQuery({
    queryKey: [`/api/videos/${videoId}`],
    enabled: isDetailView,
  });
  
  useEffect(() => {
    if (isDetailView && videoDetail) {
      setSelectedVideo(videoDetail);
    } else if (videos && videos.length > 0 && !isDetailView) {
      setSelectedVideo(videos[0]);
    }
  }, [videoDetail, videos, isDetailView]);
  
  const isLoading = allVideosLoading || (isDetailView && videoDetailLoading);
  const error = allVideosError || (isDetailView && videoDetailError);
  
  const handleVideoSelect = (video: Video) => {
    setSelectedVideo(video);
  };
  
  if (isLoading) {
    return (
      <div className="pt-24 pb-16 container mx-auto px-6 md:px-12">
        <div className="w-full flex justify-center items-center py-20">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }
  
  if (error || !videos) {
    return (
      <div className="pt-24 pb-16 container mx-auto px-6 md:px-12">
        <div className="bg-[#1A1A1A] p-6 rounded-sm text-center my-10">
          <h2 className="text-xl font-bold mb-2">Failed to load videos</h2>
          <p className="text-gray-400 mb-4">Please try again later</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-6 md:px-12">
        <h1 className="text-4xl font-bold mb-8">
          {isDetailView ? 'Video' : 'All Videos'}
        </h1>
        
        {selectedVideo && (
          <div className="mb-12">
            <VideoPlayer 
              videoId={selectedVideo.youtubeId} 
              title={selectedVideo.title}
              showControls={true}
              className="mb-6"
            />
            <h2 className="text-2xl font-bold mb-2">{selectedVideo.title}</h2>
            <div className="flex flex-wrap gap-4 text-sm text-gray-400 mb-4">
              <span className="flex items-center">
                <Calendar className="h-4 w-4 mr-1 text-primary" />
                {new Date(selectedVideo.publishedAt).toLocaleDateString('en-US', {
                  month: 'long',
                  day: 'numeric',
                  year: 'numeric'
                })}
              </span>
              <span className="flex items-center">
                <Clock className="h-4 w-4 mr-1 text-primary" />
                {selectedVideo.duration}
              </span>
              <span className="flex items-center">
                <Eye className="h-4 w-4 mr-1 text-primary" />
                {selectedVideo.views?.toLocaleString() || '0'} views
              </span>
            </div>
            <p className="text-gray-300">{selectedVideo.description}</p>
          </div>
        )}
        
        <h3 className="text-2xl font-bold mb-6">
          {isDetailView ? 'More Videos' : 'All Videos'}
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videos
            .filter(video => !isDetailView || video.id !== parseInt(videoId!))
            .map((video: Video) => (
              <div 
                key={video.id} 
                className={`group transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-primary/20 cursor-pointer ${selectedVideo?.id === video.id && !isDetailView ? 'border-l-4 border-primary pl-3' : ''}`}
                onClick={() => handleVideoSelect(video)}
              >
                <div className="relative overflow-hidden mb-4">
                  <img 
                    src={video.thumbnailUrl || `https://i.ytimg.com/vi/${video.youtubeId}/maxresdefault.jpg`}
                    alt={video.title} 
                    className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-14 h-14 rounded-full bg-black bg-opacity-50 flex items-center justify-center transition-transform duration-300 hover:scale-110">
                      <Play className="text-primary h-8 w-8" />
                    </div>
                  </div>
                  <div className="absolute bottom-3 right-3 bg-black bg-opacity-70 px-2 py-1 flex items-center space-x-1">
                    <Clock className="h-3 w-3 text-primary" />
                    <span className="font-mono text-xs">{video.duration}</span>
                  </div>
                </div>
                <h3 className="font-bold text-xl mb-2 group-hover:text-primary transition-colors">{video.title}</h3>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">{video.views?.toLocaleString() || '0'} views</span>
                  <span className="text-primary font-mono text-sm">
                    {new Date(video.publishedAt).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric', 
                      year: 'numeric' 
                    })}
                  </span>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default VideoPage;
