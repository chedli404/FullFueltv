import HeroSection from '@/components/HeroSection';
import FeaturedVideos from '@/components/FeaturedVideos';
import EventsSection from '@/components/EventsSection';
import MusicSection from '@/components/MusicSection';
import GallerySection from '@/components/GallerySection';
import AboutSection from '@/components/AboutSection';

const Home = () => {
  return (
    <>
      <HeroSection />
      <FeaturedVideos />
      <EventsSection />
      <MusicSection />
      <GallerySection />
      <AboutSection />
    </>
  );
};

export default Home;
