import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { InstagramIcon, X } from 'lucide-react';
import { Gallery as GalleryItem } from '@shared/schema';

const GalleryPage = () => {
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);
  
  const { data: gallery, isLoading, error } = useQuery({
    queryKey: ['/api/gallery'],
  });
  
  const openImage = (image: GalleryItem) => {
    setSelectedImage(image);
    document.body.classList.add('overflow-hidden');
  };
  
  const closeImage = () => {
    setSelectedImage(null);
    document.body.classList.remove('overflow-hidden');
  };
  
  if (isLoading) {
    return (
      <div className="pt-24 pb-16 container mx-auto px-6 md:px-12">
        <div className="w-full flex justify-center items-center py-20">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }
  
  if (error || !gallery) {
    return (
      <div className="pt-24 pb-16 container mx-auto px-6 md:px-12">
        <div className="bg-[#1A1A1A] p-6 rounded-sm text-center my-10">
          <h2 className="text-xl font-bold mb-2">Failed to load gallery</h2>
          <p className="text-gray-400 mb-4">Please try again later</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-6 md:px-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold">Gallery</h1>
          <a 
            href="https://www.instagram.com/fullfuel.tv/" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-primary hover:text-primary/80 font-medium flex items-center gap-2 transition-colors"
          >
            Follow on Instagram <InstagramIcon className="h-5 w-5" />
          </a>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {gallery.map((item: GalleryItem) => (
            <div 
              key={item.id} 
              className="overflow-hidden group cursor-pointer relative"
              onClick={() => openImage(item)}
            >
              <img 
                src={item.imageUrl}
                alt={item.caption || 'Gallery image'} 
                className="w-full h-60 object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <InstagramIcon className="text-white h-10 w-10" />
              </div>
              {item.caption && (
                <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="text-white text-sm">{item.caption}</p>
                </div>
              )}
            </div>
          ))}
        </div>
        
        {/* Image Modal */}
        {selectedImage && (
          <div 
            className="fixed inset-0 z-50 bg-black bg-opacity-90 flex items-center justify-center p-4"
            onClick={closeImage}
          >
            <button 
              className="absolute top-4 right-4 text-white hover:text-primary transition-colors"
              onClick={closeImage}
            >
              <X className="h-8 w-8" />
            </button>
            
            <div 
              className="max-w-4xl max-h-[80vh] bg-[#1A1A1A] rounded-sm overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <img 
                src={selectedImage.imageUrl}
                alt={selectedImage.caption || 'Gallery image'} 
                className="max-w-full max-h-[60vh] mx-auto"
              />
              
              <div className="p-4">
                {selectedImage.caption && (
                  <p className="text-lg mb-2">{selectedImage.caption}</p>
                )}
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-400">
                    {new Date(selectedImage.publishedAt).toLocaleDateString('en-US', {
                      month: 'long',
                      day: 'numeric',
                      year: 'numeric'
                    })}
                  </p>
                  {selectedImage.instagramUrl && (
                    <a 
                      href={selectedImage.instagramUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:text-primary/80 flex items-center gap-1 transition-colors"
                      onClick={(e) => e.stopPropagation()}
                    >
                      View on Instagram <InstagramIcon className="h-4 w-4" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div className="mt-16 bg-[#1A1A1A] p-8 rounded-sm">
          <div className="flex flex-col md:flex-row justify-between gap-8">
            <div className="md:w-2/3">
              <h2 className="text-2xl font-bold mb-4">Submit Your Photos</h2>
              <p className="mb-6">
                Were you at one of our events? Share your photos with us by tagging <span className="text-primary">@fullfuel.tv</span> on Instagram or using the hashtag <span className="text-primary">#fullfueltv</span>
              </p>
              <a 
                href="https://www.instagram.com/fullfuel.tv/" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-flex items-center bg-primary hover:bg-primary/80 text-dark px-6 py-3 rounded-sm font-medium transition-colors uppercase gap-2"
              >
                Follow Us on Instagram <InstagramIcon className="h-5 w-5" />
              </a>
            </div>
            <div className="md:w-1/3 flex items-center justify-center">
              <InstagramIcon className="h-32 w-32 text-primary opacity-20" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GalleryPage;
