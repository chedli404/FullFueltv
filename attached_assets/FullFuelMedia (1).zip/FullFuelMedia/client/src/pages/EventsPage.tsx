import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { MapPin, Calendar, Users, ExternalLink } from 'lucide-react';
import { Event } from '@shared/schema';

const EventsPage = () => {
  const [location] = useLocation();
  const [eventType, setEventType] = useState('all');
  
  // Get event ID from URL if present
  const eventId = location.split('/').pop();
  const isDetailView = eventId && !isNaN(Number(eventId));
  
  // Fetch all events
  const { data: events, isLoading: allEventsLoading, error: allEventsError } = useQuery({
    queryKey: ['/api/events'],
  });
  
  // Fetch specific event if in detail view
  const { data: eventDetail, isLoading: eventDetailLoading, error: eventDetailError } = useQuery({
    queryKey: [`/api/events/${eventId}`],
    enabled: isDetailView,
  });
  
  const isLoading = allEventsLoading || (isDetailView && eventDetailLoading);
  const error = allEventsError || (isDetailView && eventDetailError);
  
  const filteredEvents = eventType === 'all' 
    ? events 
    : events?.filter((event: Event) => event.eventType === eventType);
  
  const handleFilterChange = (type: string) => {
    setEventType(type);
  };
  
  if (isLoading) {
    return (
      <div className="pt-24 pb-16 container mx-auto px-6 md:px-12">
        <div className="w-full flex justify-center items-center py-20">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }
  
  if (error || !events) {
    return (
      <div className="pt-24 pb-16 container mx-auto px-6 md:px-12">
        <div className="bg-[#1A1A1A] p-6 rounded-sm text-center my-10">
          <h2 className="text-xl font-bold mb-2">Failed to load events</h2>
          <p className="text-gray-400 mb-4">Please try again later</p>
        </div>
      </div>
    );
  }
  
  // If it's a detail view, show the selected event
  if (isDetailView && eventDetail) {
    return (
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-6 md:px-12">
          <div className="mb-8">
            <a href="/events" className="text-primary hover:underline flex items-center gap-2">
              <span>← Back to all events</span>
            </a>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="relative overflow-hidden rounded-sm">
                <img 
                  src={eventDetail.imageUrl || 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3'}
                  alt={eventDetail.title} 
                  className="w-full h-96 object-cover"
                />
                <div className="absolute top-0 left-0 m-4 bg-primary px-3 py-1">
                  <span className="font-mono text-dark text-sm uppercase font-bold">
                    {new Date(eventDetail.date).toLocaleDateString('en-US', { 
                      day: '2-digit', 
                      month: 'short' 
                    })}
                  </span>
                </div>
              </div>
              
              <h1 className="text-3xl font-bold mt-6 mb-4">{eventDetail.title}</h1>
              
              <div className="flex flex-wrap gap-4 text-sm text-gray-400 mb-6">
                <span className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1 text-primary" />
                  {new Date(eventDetail.date).toLocaleDateString('en-US', {
                    weekday: 'long',
                    month: 'long',
                    day: 'numeric',
                    year: 'numeric'
                  })}
                </span>
                <span className="flex items-center">
                  <MapPin className="h-4 w-4 mr-1 text-primary" />
                  {eventDetail.location}
                </span>
                <span className="flex items-center">
                  <Users className="h-4 w-4 mr-1 text-primary" />
                  {eventDetail.attending?.toLocaleString() || '0'} attending
                </span>
              </div>
              
              <div className="prose prose-invert prose-sm max-w-none mb-8">
                <p>{eventDetail.description}</p>
              </div>
              
              {eventDetail.facebookEventId && (
                <a 
                  href={`https://facebook.com/events/${eventDetail.facebookEventId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-primary hover:bg-opacity-80 text-dark px-6 py-3 rounded-sm font-medium transition-colors uppercase"
                >
                  Facebook Event <ExternalLink className="h-4 w-4" />
                </a>
              )}
            </div>
            
            <div className="lg:col-span-1">
              <div className="bg-[#1A1A1A] p-6 rounded-sm">
                <h3 className="text-xl font-bold mb-4">Event Details</h3>
                
                <div className="space-y-4">
                  <div className="flex flex-col">
                    <span className="text-gray-400 text-sm">Date & Time</span>
                    <span className="font-medium">
                      {new Date(eventDetail.date).toLocaleDateString('en-US', {
                        weekday: 'long',
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                  
                  <div className="flex flex-col">
                    <span className="text-gray-400 text-sm">Location</span>
                    <span className="font-medium">{eventDetail.location}</span>
                  </div>
                  
                  <div className="flex flex-col">
                    <span className="text-gray-400 text-sm">Event Type</span>
                    <span className="font-medium capitalize">{eventDetail.eventType}</span>
                  </div>
                  
                  <div className="flex flex-col">
                    <span className="text-gray-400 text-sm">Attendees</span>
                    <span className="font-medium">{eventDetail.attending?.toLocaleString() || '0'} people</span>
                  </div>
                </div>
                
                <div className="mt-6">
                  <a 
                    href="#" 
                    className="w-full block text-center bg-primary hover:bg-opacity-80 text-dark px-6 py-3 rounded-sm font-medium transition-colors uppercase"
                  >
                    RSVP Now
                  </a>
                </div>
              </div>
              
              <div className="bg-[#1A1A1A] p-6 rounded-sm mt-6">
                <h3 className="text-xl font-bold mb-4">Share Event</h3>
                
                <div className="flex space-x-4">
                  <a 
                    href={`https://facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#1877F2] hover:bg-opacity-80 text-white p-2 rounded-sm"
                    aria-label="Share on Facebook"
                  >
                    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
                    </svg>
                  </a>
                  
                  <a 
                    href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(`Check out ${eventDetail.title} on Full Fuel TV`)}&url=${encodeURIComponent(window.location.href)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#1DA1F2] hover:bg-opacity-80 text-white p-2 rounded-sm"
                    aria-label="Share on Twitter"
                  >
                    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                    </svg>
                  </a>
                  
                  <a 
                    href={`mailto:?subject=${encodeURIComponent(`Check out ${eventDetail.title} on Full Fuel TV`)}&body=${encodeURIComponent(`I thought you might be interested in this event: ${window.location.href}`)}`}
                    className="bg-gray-700 hover:bg-opacity-80 text-white p-2 rounded-sm"
                    aria-label="Share via Email"
                  >
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6">More Events</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {events
                .filter(event => event.id !== eventDetail.id)
                .slice(0, 3)
                .map((event: Event) => (
                  <a 
                    key={event.id} 
                    href={`/events/${event.id}`}
                    className="group transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-primary/20"
                  >
                    <div className="relative overflow-hidden mb-4">
                      <img 
                        src={event.imageUrl || 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3'}
                        alt={event.title} 
                        className="w-full h-64 object-cover"
                      />
                      <div className="absolute top-0 left-0 m-4 bg-primary px-3 py-1">
                        <span className="font-mono text-dark text-sm uppercase font-bold">
                          {new Date(event.date).toLocaleDateString('en-US', { 
                            day: '2-digit', 
                            month: 'short' 
                          })}
                        </span>
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent">
                        <h3 className="font-bold text-xl mb-1 group-hover:text-primary transition-colors">{event.title}</h3>
                        <p className="text-gray-300">{event.location}</p>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2">
                        <Users className="h-4 w-4 text-primary" />
                        <span className="text-sm">{event.attending.toLocaleString()} attending</span>
                      </div>
                      <span className="text-primary hover:text-white transition-colors font-medium text-sm">Details</span>
                    </div>
                  </a>
                ))}
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // If it's not a detail view, show all events with filters
  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-6 md:px-12">
        <h1 className="text-4xl font-bold mb-8">Events</h1>
        
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center">
            <span className="text-lg mr-4">Filter by:</span>
            <div className="hidden md:flex space-x-4">
              <button 
                className={`px-4 py-2 ${eventType === 'all' ? 'bg-primary text-dark' : 'bg-[#1A1A1A] hover:bg-primary hover:text-dark'} text-white transition-colors rounded-sm`}
                onClick={() => handleFilterChange('all')}
              >
                All
              </button>
              <button 
                className={`px-4 py-2 ${eventType === 'festival' ? 'bg-primary text-dark' : 'bg-[#1A1A1A] hover:bg-primary hover:text-dark'} text-white transition-colors rounded-sm`}
                onClick={() => handleFilterChange('festival')}
              >
                Festivals
              </button>
              <button 
                className={`px-4 py-2 ${eventType === 'club' ? 'bg-primary text-dark' : 'bg-[#1A1A1A] hover:bg-primary hover:text-dark'} text-white transition-colors rounded-sm`}
                onClick={() => handleFilterChange('club')}
              >
                Clubs
              </button>
              <button 
                className={`px-4 py-2 ${eventType === 'livestream' ? 'bg-primary text-dark' : 'bg-[#1A1A1A] hover:bg-primary hover:text-dark'} text-white transition-colors rounded-sm`}
                onClick={() => handleFilterChange('livestream')}
              >
                Livestreams
              </button>
            </div>
          </div>
        </div>
        
        <div className="flex overflow-x-auto md:hidden space-x-4 mb-8 pb-2">
          <button 
            className={`whitespace-nowrap px-4 py-2 ${eventType === 'all' ? 'bg-primary text-dark' : 'bg-[#1A1A1A] hover:bg-primary hover:text-dark'} text-white transition-colors rounded-sm`}
            onClick={() => handleFilterChange('all')}
          >
            All
          </button>
          <button 
            className={`whitespace-nowrap px-4 py-2 ${eventType === 'festival' ? 'bg-primary text-dark' : 'bg-[#1A1A1A] hover:bg-primary hover:text-dark'} text-white transition-colors rounded-sm`}
            onClick={() => handleFilterChange('festival')}
          >
            Festivals
          </button>
          <button 
            className={`whitespace-nowrap px-4 py-2 ${eventType === 'club' ? 'bg-primary text-dark' : 'bg-[#1A1A1A] hover:bg-primary hover:text-dark'} text-white transition-colors rounded-sm`}
            onClick={() => handleFilterChange('club')}
          >
            Clubs
          </button>
          <button 
            className={`whitespace-nowrap px-4 py-2 ${eventType === 'livestream' ? 'bg-primary text-dark' : 'bg-[#1A1A1A] hover:bg-primary hover:text-dark'} text-white transition-colors rounded-sm`}
            onClick={() => handleFilterChange('livestream')}
          >
            Livestreams
          </button>
        </div>
        
        {filteredEvents && filteredEvents.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredEvents.map((event: Event) => (
              <a 
                key={event.id} 
                href={`/events/${event.id}`}
                className="group transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-primary/20"
              >
                <div className="relative overflow-hidden mb-4">
                  <img 
                    src={event.imageUrl || 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3'}
                    alt={event.title} 
                    className="w-full h-64 object-cover"
                  />
                  <div className="absolute top-0 left-0 m-4 bg-primary px-3 py-1">
                    <span className="font-mono text-dark text-sm uppercase font-bold">
                      {new Date(event.date).toLocaleDateString('en-US', { 
                        day: '2-digit', 
                        month: 'short' 
                      })}
                    </span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent">
                    <h3 className="font-bold text-xl mb-1 group-hover:text-primary transition-colors">{event.title}</h3>
                    <p className="text-gray-300">{event.location}</p>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-primary" />
                    <span className="text-sm">{event.attending.toLocaleString()} attending</span>
                  </div>
                  <span className="text-primary hover:text-white transition-colors font-medium text-sm">Details</span>
                </div>
              </a>
            ))}
          </div>
        ) : (
          <div className="bg-[#1A1A1A] p-6 rounded-sm text-center">
            <Calendar className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">No events found</h3>
            <p className="text-gray-400 mb-4">There are no upcoming events in this category</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default EventsPage;
