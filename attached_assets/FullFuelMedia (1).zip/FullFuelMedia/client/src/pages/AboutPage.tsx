import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { insertContactSchema } from '@shared/schema';
import { z } from 'zod';
import { YoutubeIcon, InstagramIcon, FacebookIcon, Mail, MapPin, AlertCircle, Check } from 'lucide-react';

// Extend the contact schema with validation
const contactFormSchema = insertContactSchema.extend({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  message: z.string().min(10, { message: "Message must be at least 10 characters" }),
});

type ContactFormData = z.infer<typeof contactFormSchema>;

const AboutPage = () => {
  const [submitted, setSubmitted] = useState(false);
  const { toast } = useToast();
  
  const { register, handleSubmit, formState: { errors }, reset } = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: '',
      email: '',
      message: '',
    }
  });
  
  const contactMutation = useMutation({
    mutationFn: (data: ContactFormData) => {
      return apiRequest('POST', '/api/contact', data);
    },
    onSuccess: () => {
      setSubmitted(true);
      reset();
      toast({
        title: "Message Sent!",
        description: "Thank you for contacting us. We'll respond as soon as possible.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error.message || "There was an error sending your message. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  const onSubmit = (data: ContactFormData) => {
    contactMutation.mutate({
      ...data,
      createdAt: new Date(),
    });
  };
  
  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-6 md:px-12">
        {/* About Section */}
        <section className="mb-20">
          <h1 className="text-4xl font-bold mb-6">About Full Fuel</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <p className="text-lg mb-6">
                Full Fuel explores waves, by collecting the best music live sets & DJ mixes from Clubs & Festivals. 
                We provide the best performance to be bigger and better. An incredible talent will made the events 
                quite special.
              </p>
              <p className="text-lg mb-6">
                Founded in 2015, we've been at the forefront of electronic music culture, documenting and 
                broadcasting the most cutting-edge sounds from around the world.
              </p>
              <p className="text-lg mb-6">
                Our mission is to bridge the gap between artists and audiences, bringing the energy and atmosphere 
                of live electronic music performances to viewers worldwide. We collaborate with renowned DJs, 
                innovative producers, and iconic venues to create unforgettable musical experiences.
              </p>
              <p className="text-lg mb-12">
                Full Fuel TV has become a platform where music enthusiasts can discover new talent, revisit legendary 
                performances, and stay connected to the global electronic music community.
              </p>
            </div>
            
            <div className="bg-[#1A1A1A] p-8 rounded-sm">
              <h2 className="text-2xl font-bold mb-6">Connect With Us</h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <YoutubeIcon className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-bold mb-1">YouTube</h3>
                    <p className="text-gray-400 mb-2">Subscribe to our channel for the latest sets and performances</p>
                    <a 
                      href="https://www.youtube.com/c/FullFuel" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:text-primary/80 transition-colors"
                    >
                      youtube.com/c/FullFuel
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <InstagramIcon className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-bold mb-1">Instagram</h3>
                    <p className="text-gray-400 mb-2">Follow us for event photos, artist spotlights, and behind-the-scenes content</p>
                    <a 
                      href="https://www.instagram.com/fullfuel.tv/" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:text-primary/80 transition-colors"
                    >
                      @fullfuel.tv
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <FacebookIcon className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-bold mb-1">Facebook</h3>
                    <p className="text-gray-400 mb-2">Like our page for event announcements and community updates</p>
                    <a 
                      href="https://www.facebook.com/FullFuel.tv/" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:text-primary/80 transition-colors"
                    >
                      facebook.com/FullFuel.tv
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Our Team Section */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold mb-8">Our Team</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Team Member 1 */}
            <div className="bg-[#1A1A1A] rounded-sm overflow-hidden">
              <div className="h-64 bg-gray-800">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Alex Rodriguez</h3>
                <p className="text-primary mb-4">Founder & Creative Director</p>
                <p className="text-gray-400">
                  Passionate about electronic music and visual storytelling, Alex founded Full Fuel to showcase the world's best music experiences.
                </p>
              </div>
            </div>
            
            {/* Team Member 2 */}
            <div className="bg-[#1A1A1A] rounded-sm overflow-hidden">
              <div className="h-64 bg-gray-800">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Maria Chen</h3>
                <p className="text-primary mb-4">Head of Production</p>
                <p className="text-gray-400">
                  With over 10 years in music video production, Maria leads our team in capturing the perfect moments from every event.
                </p>
              </div>
            </div>
            
            {/* Team Member 3 */}
            <div className="bg-[#1A1A1A] rounded-sm overflow-hidden">
              <div className="h-64 bg-gray-800">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Thomas Weber</h3>
                <p className="text-primary mb-4">Music Director</p>
                <p className="text-gray-400">
                  DJ and producer Thomas curates our musical content and builds relationships with artists and labels worldwide.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Contact Section */}
        <section id="contact" className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-3xl font-bold mb-6">Contact Us</h2>
            <p className="mb-8">
              Have questions, partnership proposals, or just want to say hello? We'd love to hear from you! 
              Fill out the form and our team will get back to you as soon as possible.
            </p>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start space-x-4">
                <Mail className="h-6 w-6 text-primary mt-1" />
                <div>
                  <h3 className="font-bold mb-1">Email Us</h3>
                  <a href="mailto:info@fullfuel.tv" className="text-primary hover:text-primary/80 transition-colors">
                    info@fullfuel.tv
                  </a>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <MapPin className="h-6 w-6 text-primary mt-1" />
                <div>
                  <h3 className="font-bold mb-1">Location</h3>
                  <p>Amsterdam, Netherlands</p>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-6">
              <a 
                href="https://www.youtube.com/c/FullFuel" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-white hover:text-primary transition-colors"
                aria-label="YouTube"
              >
                <YoutubeIcon className="h-7 w-7" />
              </a>
              <a 
                href="https://www.instagram.com/fullfuel.tv/" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-white hover:text-primary transition-colors"
                aria-label="Instagram"
              >
                <InstagramIcon className="h-7 w-7" />
              </a>
              <a 
                href="https://www.facebook.com/FullFuel.tv/" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-white hover:text-primary transition-colors"
                aria-label="Facebook"
              >
                <FacebookIcon className="h-7 w-7" />
              </a>
            </div>
          </div>
          
          <div className="bg-[#1A1A1A] p-8 rounded-sm">
            {submitted ? (
              <div className="flex flex-col items-center justify-center h-full py-12">
                <div className="bg-primary/20 p-6 rounded-full mb-6">
                  <Check className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Thank You!</h3>
                <p className="text-center text-gray-400 mb-6">
                  Your message has been sent. We'll get back to you as soon as possible.
                </p>
                <button 
                  onClick={() => setSubmitted(false)}
                  className="text-primary hover:text-primary/80 transition-colors font-medium"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)}>
                <h3 className="text-2xl font-bold mb-6">Send Us a Message</h3>
                
                <div className="mb-4">
                  <label htmlFor="name" className="block text-sm font-medium mb-2">Name</label>
                  <input 
                    id="name"
                    type="text"
                    {...register('name')}
                    className={`w-full bg-black border ${errors.name ? 'border-red-500' : 'border-gray-700'} rounded-sm px-4 py-3 focus:outline-none focus:border-primary`}
                    placeholder="Your name"
                  />
                  {errors.name && (
                    <p className="mt-1 text-sm text-red-500 flex items-center">
                      <AlertCircle className="h-3 w-3 mr-1" />
                      {errors.name.message}
                    </p>
                  )}
                </div>
                
                <div className="mb-4">
                  <label htmlFor="email" className="block text-sm font-medium mb-2">Email</label>
                  <input 
                    id="email"
                    type="email"
                    {...register('email')}
                    className={`w-full bg-black border ${errors.email ? 'border-red-500' : 'border-gray-700'} rounded-sm px-4 py-3 focus:outline-none focus:border-primary`}
                    placeholder="Your email address"
                  />
                  {errors.email && (
                    <p className="mt-1 text-sm text-red-500 flex items-center">
                      <AlertCircle className="h-3 w-3 mr-1" />
                      {errors.email.message}
                    </p>
                  )}
                </div>
                
                <div className="mb-6">
                  <label htmlFor="message" className="block text-sm font-medium mb-2">Message</label>
                  <textarea 
                    id="message"
                    {...register('message')}
                    rows={5}
                    className={`w-full bg-black border ${errors.message ? 'border-red-500' : 'border-gray-700'} rounded-sm px-4 py-3 focus:outline-none focus:border-primary`}
                    placeholder="Your message"
                  ></textarea>
                  {errors.message && (
                    <p className="mt-1 text-sm text-red-500 flex items-center">
                      <AlertCircle className="h-3 w-3 mr-1" />
                      {errors.message.message}
                    </p>
                  )}
                </div>
                
                <button 
                  type="submit"
                  disabled={contactMutation.isPending}
                  className="w-full bg-primary hover:bg-primary/80 text-dark px-6 py-3 rounded-sm font-medium transition-colors uppercase"
                >
                  {contactMutation.isPending ? 'Sending...' : 'Send Message'}
                </button>
              </form>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

export default AboutPage;
