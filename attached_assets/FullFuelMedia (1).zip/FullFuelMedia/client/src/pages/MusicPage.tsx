import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Play, Pause, Clock, Calendar, User } from 'lucide-react';
import { Mix } from '@shared/schema';

const MusicPage = () => {
  const [activeMix, setActiveMix] = useState<number | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  
  const { data: mixes, isLoading, error } = useQuery({
    queryKey: ['/api/mixes'],
  });
  
  const handlePlayClick = (id: number) => {
    if (activeMix === id) {
      setIsPlaying(!isPlaying);
    } else {
      setActiveMix(id);
      setIsPlaying(true);
    }
  };
  
  if (isLoading) {
    return (
      <div className="pt-24 pb-16 container mx-auto px-6 md:px-12">
        <div className="w-full flex justify-center items-center py-20">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }
  
  if (error || !mixes || mixes.length === 0) {
    return (
      <div className="pt-24 pb-16 container mx-auto px-6 md:px-12">
        <div className="bg-[#1A1A1A] p-6 rounded-sm text-center my-10">
          <h2 className="text-xl font-bold mb-2">Failed to load music</h2>
          <p className="text-gray-400 mb-4">Please try again later</p>
        </div>
      </div>
    );
  }
  
  // Split mixes into featured (first one) and the rest
  const featuredMix = mixes[0];
  const restOfMixes = mixes.slice(1);
  
  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-6 md:px-12">
        <h1 className="text-4xl font-bold mb-12">Music</h1>
        
        {/* Featured Mix */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold mb-6">Featured Mix</h2>
          
          <div className="bg-[#1A1A1A] rounded-sm p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="relative md:col-span-1">
                <img 
                  src={featuredMix.imageUrl || `https://images.unsplash.com/photo-1583331530804-9b2fa2cdfbb9`}
                  alt={featuredMix.title} 
                  className="w-full aspect-square object-cover rounded-sm"
                />
                <button
                  onClick={() => handlePlayClick(featuredMix.id)}
                  className="absolute inset-0 flex items-center justify-center"
                >
                  <div className="w-20 h-20 rounded-full bg-primary flex items-center justify-center transition-transform duration-300 hover:scale-110">
                    {activeMix === featuredMix.id && isPlaying ? (
                      <Pause className="text-dark h-10 w-10" />
                    ) : (
                      <Play className="text-dark h-10 w-10 ml-1" />
                    )}
                  </div>
                </button>
              </div>
              
              <div className="md:col-span-2">
                <h3 className="text-2xl font-bold mb-2">{featuredMix.title}</h3>
                <div className="flex flex-wrap gap-4 text-sm text-gray-400 mb-4">
                  <span className="flex items-center">
                    <User className="h-4 w-4 mr-1 text-primary" />
                    {featuredMix.artist}
                  </span>
                  <span className="flex items-center">
                    <Clock className="h-4 w-4 mr-1 text-primary" />
                    {featuredMix.duration}
                  </span>
                  <span className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1 text-primary" />
                    {new Date(featuredMix.publishedAt).toLocaleDateString('en-US', {
                      month: 'long',
                      day: 'numeric',
                      year: 'numeric'
                    })}
                  </span>
                </div>
                
                <p className="text-gray-300 mb-6">{featuredMix.description}</p>
                
                {activeMix === featuredMix.id && isPlaying && (
                  <div className="w-full h-16 bg-black bg-opacity-50 rounded-sm flex items-center px-4">
                    <div className="w-full max-w-md mx-auto flex items-center">
                      <div className="animate-pulse mr-3">
                        <span className="bg-primary inline-block w-1 h-3"></span>
                        <span className="bg-primary inline-block w-1 h-5 mx-1"></span>
                        <span className="bg-primary inline-block w-1 h-7"></span>
                        <span className="bg-primary inline-block w-1 h-4 mx-1"></span>
                        <span className="bg-primary inline-block w-1 h-2"></span>
                      </div>
                      <span className="text-sm">Now playing: {featuredMix.title} by {featuredMix.artist}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {activeMix === featuredMix.id && isPlaying && (
              <div className="mt-6">
                <iframe
                  width="100%"
                  height="450"
                  src={`https://www.youtube.com/embed/${featuredMix.youtubeId}?autoplay=1`}
                  title={featuredMix.title}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            )}
          </div>
        </div>
        
        {/* All Mixes */}
        <div>
          <h2 className="text-2xl font-bold mb-6">All Mixes</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {restOfMixes.map((mix: Mix) => (
              <div 
                key={mix.id} 
                className="bg-[#1A1A1A] rounded-sm overflow-hidden hover:shadow-lg hover:shadow-primary/20 transition-all duration-300"
              >
                <div className="relative">
                  <img 
                    src={mix.imageUrl || `https://images.unsplash.com/photo-1583331530804-9b2fa2cdfbb9`}
                    alt={mix.title} 
                    className="w-full h-48 object-cover"
                  />
                  <button
                    onClick={() => handlePlayClick(mix.id)}
                    className="absolute inset-0 flex items-center justify-center"
                  >
                    <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center transition-transform duration-300 hover:scale-110">
                      {activeMix === mix.id && isPlaying ? (
                        <Pause className="text-dark h-6 w-6" />
                      ) : (
                        <Play className="text-dark h-6 w-6 ml-0.5" />
                      )}
                    </div>
                  </button>
                  <div className="absolute bottom-3 right-3 bg-black bg-opacity-70 px-2 py-1 flex items-center space-x-1">
                    <Clock className="h-3 w-3 text-primary" />
                    <span className="font-mono text-xs">{mix.duration}</span>
                  </div>
                </div>
                
                <div className="p-4">
                  <h3 className="font-bold text-xl mb-1">{mix.title}</h3>
                  <p className="text-gray-400 text-sm mb-4">{mix.artist}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-xs">
                      {new Date(mix.publishedAt).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </span>
                    <button 
                      onClick={() => handlePlayClick(mix.id)}
                      className="text-primary hover:text-white transition-colors text-sm font-medium"
                    >
                      {activeMix === mix.id && isPlaying ? 'Pause' : 'Play'}
                    </button>
                  </div>
                </div>
                
                {activeMix === mix.id && isPlaying && (
                  <div className="px-4 pb-4">
                    <iframe
                      width="100%"
                      height="200"
                      src={`https://www.youtube.com/embed/${mix.youtubeId}?autoplay=1`}
                      title={mix.title}
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MusicPage;
