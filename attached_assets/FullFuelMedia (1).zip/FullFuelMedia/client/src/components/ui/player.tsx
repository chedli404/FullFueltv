import React, { useState, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX } from 'lucide-react';

interface VideoPlayerProps {
  videoId: string;
  title?: string;
  autoplay?: boolean;
  showControls?: boolean;
  className?: string;
  aspectRatio?: 'wide' | 'square';
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({
  videoId,
  title = '',
  autoplay = false,
  showControls = true,
  className = '',
  aspectRatio = 'wide'
}) => {
  const [playing, setPlaying] = useState(autoplay);
  const [muted, setMuted] = useState(true);
  
  // Calculate aspect ratio padding
  const paddingBottom = aspectRatio === 'wide' ? '56.25%' : '100%'; // 16:9 or 1:1
  
  return (
    <div className={`relative ${className}`}>
      <div className="video-aspect-ratio" style={{ position: 'relative', paddingBottom, height: 0, overflow: 'hidden' }}>
        <iframe
          src={`https://www.youtube.com/embed/${videoId}?autoplay=${autoplay ? 1 : 0}&mute=${muted ? 1 : 0}&controls=${showControls ? 1 : 0}&modestbranding=1&showinfo=0&rel=0`}
          title={title}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
        />
      </div>
      
      {!showControls && (
        <div className="absolute bottom-4 right-4 flex space-x-2">
          <button 
            onClick={() => setPlaying(!playing)} 
            className="w-10 h-10 bg-black/70 rounded-full flex items-center justify-center text-white hover:bg-primary hover:text-black transition-colors"
          >
            {playing ? <Pause size={20} /> : <Play size={20} />}
          </button>
          <button 
            onClick={() => setMuted(!muted)}
            className="w-10 h-10 bg-black/70 rounded-full flex items-center justify-center text-white hover:bg-primary hover:text-black transition-colors"
          >
            {muted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
        </div>
      )}
    </div>
  );
};

export default VideoPlayer;
