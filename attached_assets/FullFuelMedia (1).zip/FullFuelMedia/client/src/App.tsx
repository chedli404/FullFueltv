import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import VideoPage from "@/pages/VideoPage";
import EventsPage from "@/pages/EventsPage";
import MusicPage from "@/pages/MusicPage";
import GalleryPage from "@/pages/GalleryPage";
import AboutPage from "@/pages/AboutPage";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import LiveNowButton from "@/components/LiveNowButton";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/videos" component={VideoPage} />
      <Route path="/events" component={EventsPage} />
      <Route path="/music" component={MusicPage} />
      <Route path="/gallery" component={GalleryPage} />
      <Route path="/about" component={AboutPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex flex-col min-h-screen bg-black text-white">
        <Header />
        <main className="flex-grow">
          <Router />
        </main>
        <Footer />
        <LiveNowButton />
        <Toaster />
      </div>
    </QueryClientProvider>
  );
}

export default App;
