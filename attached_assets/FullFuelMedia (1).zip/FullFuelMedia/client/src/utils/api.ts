import { Video, Event, Mix, Gallery } from '@shared/schema';

// YouTube API helpers
export const getYouTubeThumbnailUrl = (videoId: string, quality: 'default' | 'medium' | 'high' | 'standard' | 'maxres' = 'maxres'): string => {
  return `https://i.ytimg.com/vi/${videoId}/${quality}default.jpg`;
};

export const getYoutubeEmbed = (videoId: string, autoplay: boolean = false): string => {
  return `https://www.youtube.com/embed/${videoId}?autoplay=${autoplay ? 1 : 0}`;
};

// Format date helper
export const formatDate = (date: Date | string, format: 'short' | 'medium' | 'long' = 'medium'): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  switch (format) {
    case 'short':
      return dateObj.toLocaleDateString('en-US', { 
        day: '2-digit', 
        month: 'short' 
      });
    case 'long':
      return dateObj.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      });
    case 'medium':
    default:
      return dateObj.toLocaleDateString('en-US', { 
        month: 'long', 
        day: 'numeric', 
        year: 'numeric' 
      });
  }
};

// Format number with commas
export const formatNumber = (num: number): string => {
  return num.toLocaleString();
};

// Social media URL helpers
export const getSocialMediaLinks = () => {
  return {
    youtube: 'https://www.youtube.com/c/FullFuel',
    instagram: 'https://www.instagram.com/fullfuel.tv/',
    facebook: 'https://www.facebook.com/FullFuel.tv/',
  };
};

// Filter helpers
export const filterEventsByType = (events: Event[], type: string): Event[] => {
  if (type === 'all') return events;
  return events.filter(event => event.eventType === type);
};

// Get upcoming events (events with a date in the future)
export const getUpcomingEvents = (events: Event[]): Event[] => {
  const now = new Date();
  return events
    .filter(event => new Date(event.date) > now)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
};

// Get featured videos
export const getFeaturedVideos = (videos: Video[]): Video[] => {
  return videos
    .filter(video => video.featured)
    .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
};

// Get featured mixes
export const getFeaturedMixes = (mixes: Mix[]): Mix[] => {
  return mixes
    .filter(mix => mix.featured)
    .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
};

// Format duration helper (00:00 format to human readable)
export const formatDuration = (duration: string): string => {
  const parts = duration.split(':');
  
  if (parts.length === 2) {
    // Format: MM:SS
    return `${parts[0]}m ${parts[1]}s`;
  } else if (parts.length === 3) {
    // Format: HH:MM:SS
    if (parts[0] === '00') {
      return `${parseInt(parts[1])}m ${parts[2]}s`;
    }
    return `${parseInt(parts[0])}h ${parseInt(parts[1])}m`;
  }
  
  return duration;
};
