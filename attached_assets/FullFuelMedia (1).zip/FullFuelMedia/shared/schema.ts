import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  subscribed: boolean("subscribed").default(false),
});

// Video model
export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  youtubeId: text("youtube_id").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  duration: text("duration"),
  views: integer("views").default(0),
  featured: boolean("featured").default(false),
  publishedAt: timestamp("published_at").notNull(),
});

// Event model
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  location: text("location").notNull(),
  date: timestamp("date").notNull(),
  imageUrl: text("image_url"),
  attending: integer("attending").default(0),
  facebookEventId: text("facebook_event_id"),
  eventType: text("event_type").notNull(), // 'festival', 'club', 'livestream'
  featured: boolean("featured").default(false),
});

// Music (Mixes) model
export const mixes = pgTable("mixes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  artist: text("artist").notNull(),
  imageUrl: text("image_url"),
  youtubeId: text("youtube_id"),
  duration: text("duration"),
  publishedAt: timestamp("published_at").notNull(),
  featured: boolean("featured").default(false),
});

// Gallery model
export const gallery = pgTable("gallery", {
  id: serial("id").primaryKey(),
  imageUrl: text("image_url").notNull(),
  caption: text("caption"),
  instagramUrl: text("instagram_url"),
  publishedAt: timestamp("published_at").notNull(),
});

// Newsletter subscribers
export const subscribers = pgTable("subscribers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  agreedToMarketing: boolean("agreed_to_marketing").default(false),
  subscribedAt: timestamp("subscribed_at").notNull(),
});

// Contact messages
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  name: true,
  subscribed: true,
});

export const insertVideoSchema = createInsertSchema(videos).omit({
  id: true,
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
});

export const insertMixSchema = createInsertSchema(mixes).omit({
  id: true,
});

export const insertGallerySchema = createInsertSchema(gallery).omit({
  id: true,
});

export const insertSubscriberSchema = createInsertSchema(subscribers).omit({
  id: true,
  subscribedAt: true,
}).extend({
  subscribedAt: z.date().optional(),
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
}).extend({
  createdAt: z.date().optional(),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type Video = typeof videos.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertMix = z.infer<typeof insertMixSchema>;
export type Mix = typeof mixes.$inferSelect;

export type InsertGallery = z.infer<typeof insertGallerySchema>;
export type Gallery = typeof gallery.$inferSelect;

export type InsertSubscriber = z.infer<typeof insertSubscriberSchema>;
export type Subscriber = typeof subscribers.$inferSelect;

export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;
