import {
  users, type User, type InsertUser,
  videos, type Video, type InsertVideo,
  events, type Event, type InsertEvent,
  mixes, type Mix, type InsertMix,
  gallery, type Gallery, type InsertGallery,
  subscribers, type Subscriber, type InsertSubscriber,
  contacts, type Contact, type InsertContact
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Video methods
  getVideos(): Promise<Video[]>;
  getVideo(id: number): Promise<Video | undefined>;
  getFeaturedVideos(limit?: number): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  
  // Event methods
  getEvents(): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  getEventsByType(type: string): Promise<Event[]>;
  getFeaturedEvents(limit?: number): Promise<Event[]>;
  getUpcomingEvents(limit?: number): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  
  // Mix methods
  getMixes(): Promise<Mix[]>;
  getMix(id: number): Promise<Mix | undefined>;
  getFeaturedMixes(limit?: number): Promise<Mix[]>;
  createMix(mix: InsertMix): Promise<Mix>;
  
  // Gallery methods
  getGalleryItems(): Promise<Gallery[]>;
  getGalleryItem(id: number): Promise<Gallery | undefined>;
  createGalleryItem(item: InsertGallery): Promise<Gallery>;
  
  // Subscriber methods
  getSubscribers(): Promise<Subscriber[]>;
  getSubscriberByEmail(email: string): Promise<Subscriber | undefined>;
  createSubscriber(subscriber: InsertSubscriber): Promise<Subscriber>;
  
  // Contact methods
  getContacts(): Promise<Contact[]>;
  createContact(contact: InsertContact): Promise<Contact>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private videos: Map<number, Video>;
  private events: Map<number, Event>;
  private mixes: Map<number, Mix>;
  private galleryItems: Map<number, Gallery>;
  private subscribers: Map<number, Subscriber>;
  private contacts: Map<number, Contact>;
  
  private userCurrentId: number;
  private videoCurrentId: number;
  private eventCurrentId: number;
  private mixCurrentId: number;
  private galleryCurrentId: number;
  private subscriberCurrentId: number;
  private contactCurrentId: number;
  
  constructor() {
    this.users = new Map();
    this.videos = new Map();
    this.events = new Map();
    this.mixes = new Map();
    this.galleryItems = new Map();
    this.subscribers = new Map();
    this.contacts = new Map();
    
    this.userCurrentId = 1;
    this.videoCurrentId = 1;
    this.eventCurrentId = 1;
    this.mixCurrentId = 1;
    this.galleryCurrentId = 1;
    this.subscriberCurrentId = 1;
    this.contactCurrentId = 1;
    
    // Initialize with sample data
    this.seedData();
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Video methods
  async getVideos(): Promise<Video[]> {
    return Array.from(this.videos.values()).sort((a, b) => {
      return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
    });
  }
  
  async getVideo(id: number): Promise<Video | undefined> {
    return this.videos.get(id);
  }
  
  async getFeaturedVideos(limit: number = 3): Promise<Video[]> {
    return Array.from(this.videos.values())
      .filter(video => video.featured)
      .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
      .slice(0, limit);
  }
  
  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const id = this.videoCurrentId++;
    const video: Video = { ...insertVideo, id };
    this.videos.set(id, video);
    return video;
  }
  
  // Event methods
  async getEvents(): Promise<Event[]> {
    return Array.from(this.events.values()).sort((a, b) => {
      return new Date(a.date).getTime() - new Date(b.date).getTime();
    });
  }
  
  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }
  
  async getEventsByType(type: string): Promise<Event[]> {
    return Array.from(this.events.values())
      .filter(event => event.eventType === type)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }
  
  async getFeaturedEvents(limit: number = 3): Promise<Event[]> {
    return Array.from(this.events.values())
      .filter(event => event.featured)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, limit);
  }
  
  async getUpcomingEvents(limit: number = 3): Promise<Event[]> {
    const now = new Date();
    return Array.from(this.events.values())
      .filter(event => new Date(event.date) > now)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, limit);
  }
  
  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = this.eventCurrentId++;
    const event: Event = { ...insertEvent, id };
    this.events.set(id, event);
    return event;
  }
  
  // Mix methods
  async getMixes(): Promise<Mix[]> {
    return Array.from(this.mixes.values()).sort((a, b) => {
      return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
    });
  }
  
  async getMix(id: number): Promise<Mix | undefined> {
    return this.mixes.get(id);
  }
  
  async getFeaturedMixes(limit: number = 3): Promise<Mix[]> {
    return Array.from(this.mixes.values())
      .filter(mix => mix.featured)
      .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
      .slice(0, limit);
  }
  
  async createMix(insertMix: InsertMix): Promise<Mix> {
    const id = this.mixCurrentId++;
    const mix: Mix = { ...insertMix, id };
    this.mixes.set(id, mix);
    return mix;
  }
  
  // Gallery methods
  async getGalleryItems(): Promise<Gallery[]> {
    return Array.from(this.galleryItems.values()).sort((a, b) => {
      return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
    });
  }
  
  async getGalleryItem(id: number): Promise<Gallery | undefined> {
    return this.galleryItems.get(id);
  }
  
  async createGalleryItem(insertGallery: InsertGallery): Promise<Gallery> {
    const id = this.galleryCurrentId++;
    const item: Gallery = { ...insertGallery, id };
    this.galleryItems.set(id, item);
    return item;
  }
  
  // Subscriber methods
  async getSubscribers(): Promise<Subscriber[]> {
    return Array.from(this.subscribers.values()).sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }
  
  async getSubscriberByEmail(email: string): Promise<Subscriber | undefined> {
    return Array.from(this.subscribers.values()).find(
      (subscriber) => subscriber.email === email
    );
  }
  
  async createSubscriber(insertSubscriber: InsertSubscriber): Promise<Subscriber> {
    const id = this.subscriberCurrentId++;
    
    const subscriber: Subscriber = { 
      ...insertSubscriber, 
      id,
      createdAt: new Date()
    };
    
    this.subscribers.set(id, subscriber);
    return subscriber;
  }
  
  // Contact methods
  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values()).sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }
  
  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = this.contactCurrentId++;
    
    const contact: Contact = { 
      ...insertContact, 
      id,
      status: "pending"
    };
    
    this.contacts.set(id, contact);
    return contact;
  }
  
  private seedData() {
    // Seed videos
    const sampleVideos: InsertVideo[] = [
      {
        title: "Amelie Lens at Awakenings Festival",
        description: "Amelie Lens delivers a powerful techno set at Awakenings Festival 2023.",
        youtubeId: "RtVw0ztZwxg",
        thumbnailUrl: "https://i.ytimg.com/vi/RtVw0ztZwxg/maxresdefault.jpg",
        duration: "1:12:34",
        views: 124000,
        featured: true,
        publishedAt: new Date("2023-07-15"),
      },
      {
        title: "Charlotte de Witte KNTXT Special",
        description: "Charlotte de Witte presents a special KNTXT showcase from Printworks London.",
        youtubeId: "WkzQP5MtJug",
        thumbnailUrl: "https://i.ytimg.com/vi/WkzQP5MtJug/maxresdefault.jpg",
        duration: "45:22",
        views: 89000,
        featured: true,
        publishedAt: new Date("2023-06-01"),
      },
      {
        title: "Ben Böhmer Live at Printworks London",
        description: "Ben Böhmer performs live at the iconic Printworks venue in London.",
        youtubeId: "LvGwY9T0B6s",
        thumbnailUrl: "https://i.ytimg.com/vi/LvGwY9T0B6s/maxresdefault.jpg",
        duration: "1:34:10",
        views: 212000,
        featured: true,
        publishedAt: new Date("2023-06-22"),
      },
      {
        title: "Technasia b2b Hector",
        description: "Live from Amsterdam Dance Event, bringing the finest techno beats directly to your screen.",
        youtubeId: "fScd8Ouzmdc",
        thumbnailUrl: "https://i.ytimg.com/vi/fScd8Ouzmdc/hqdefault.jpg",
        duration: "1:50:27",
        views: 157000,
        featured: true,
        publishedAt: new Date("2023-10-20"),
      },
      {
        title: "FISHER at Tomorrowland 2023",
        description: "FISHER delivers an energetic house set at the main stage of Tomorrowland 2023.",
        youtubeId: "FGBhQbmPwH8",
        thumbnailUrl: "https://i.ytimg.com/vi/FGBhQbmPwH8/maxresdefault.jpg",
        duration: "1:05:30",
        views: 187000,
        featured: false,
        publishedAt: new Date("2023-11-15"),
      },
      {
        title: "Peggy Gou - Tokyo Boiler Room Set",
        description: "Peggy Gou spins an eclectic mix of house, disco and techno at Boiler Room Tokyo.",
        youtubeId: "sDlFWZOFp1c",
        thumbnailUrl: "https://i.ytimg.com/vi/sDlFWZOFp1c/maxresdefault.jpg",
        duration: "1:25:44",
        views: 245000,
        featured: false,
        publishedAt: new Date("2023-12-05"),
      }
    ];
    
    for (const video of sampleVideos) {
      this.createVideo(video);
    }
    
    // Seed events
    const sampleEvents: InsertEvent[] = [
      {
        title: "ADE Special: Underground Resistance",
        description: "The mysterious Detroit collective returns to Amsterdam Dance Event for a special showcase of raw and uncompromising techno.",
        eventType: "festival",
        date: new Date("2024-10-18T22:00:00"),
        location: "Warehouse Elementenstraat, Amsterdam",
        imageUrl: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7",
        attending: 450,
        featured: true,
        facebookEventId: "123456789",
      },
      {
        title: "Full Fuel Showcase: Techno Legends",
        description: "A night dedicated to the pioneers and legends of techno music, featuring exclusive back-to-back sets.",
        eventType: "club",
        date: new Date("2024-06-15T23:00:00"),
        location: "De Marktkantine, Amsterdam",
        imageUrl: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3",
        attending: 380,
        featured: true,
        facebookEventId: "987654321",
      },
      {
        title: "Sunrise Sessions: Open Air Special",
        description: "Experience the magic of electronic music as the sun rises over the city at our open-air special event.",
        eventType: "festival",
        date: new Date("2024-07-20T05:00:00"),
        location: "Blijburg aan Zee, Amsterdam",
        imageUrl: "https://images.unsplash.com/photo-1533137095095-3c589ead3255",
        attending: 625,
        featured: true,
        facebookEventId: "456789123",
      },
      {
        title: "Full Fuel Livestream: Melodic Techno Edition",
        description: "Join us online for a special livestream featuring the best melodic techno DJs from around the world.",
        eventType: "livestream",
        date: new Date("2024-05-05T20:00:00"),
        location: "Online",
        imageUrl: "https://images.unsplash.com/photo-1570587570441-148594e4c31f",
        attending: 1200,
        featured: false,
        facebookEventId: "321654987",
      }
    ];
    
    for (const event of sampleEvents) {
      this.createEvent(event);
    }
    
    // Seed mixes
    const sampleMixes: InsertMix[] = [
      {
        title: "Techno Classics: Retrospective Mix",
        description: "A journey through the iconic techno tracks that defined an era, mixed by Full Fuel resident DJ.",
        artist: "DJ Shadow",
        youtubeId: "YxGRiXH8tXM",
        imageUrl: "https://images.unsplash.com/photo-1583331530804-9b2fa2cdfbb9",
        duration: "1:25:40",
        publishedAt: new Date("2023-12-10"),
        featured: true,
      },
      {
        title: "Detroit to Berlin: Techno Evolution",
        description: "Tracing the evolution of techno from Detroit's warehouses to Berlin's clubs in this immersive mix.",
        artist: "Techno Historian",
        youtubeId: "mAz_zaImKs8",
        imageUrl: "https://images.unsplash.com/photo-1594623930572-300a3011d9ae",
        duration: "1:45:30",
        publishedAt: new Date("2023-11-15"),
        featured: true,
      },
      {
        title: "Ambient Dreamscapes Vol.1",
        description: "A selection of ambient and atmospheric tracks perfect for late-night listening sessions.",
        artist: "Lunar Echo",
        youtubeId: "IsaFt9pVOIs",
        imageUrl: "https://images.unsplash.com/photo-1600771488491-c22d42a9347d",
        duration: "1:12:45",
        publishedAt: new Date("2023-10-05"),
        featured: false,
      },
      {
        title: "Club Classics: House Edition",
        description: "Revisiting the timeless house tracks that defined the club scene of the 90s and early 2000s.",
        artist: "House Master",
        youtubeId: "IojpRe88hz0",
        imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819",
        duration: "1:38:22",
        publishedAt: new Date("2023-08-20"),
        featured: false,
      },
      {
        title: "Deep Minimal Session",
        description: "Exploring the hypnotic rhythms and subtle progressions of minimal techno in this extended set.",
        artist: "Minimal Minds",
        youtubeId: "i1c0oO1FcTk",
        imageUrl: "https://images.unsplash.com/photo-1629339942248-45d4b10f1219",
        duration: "2:05:10",
        publishedAt: new Date("2023-07-30"),
        featured: false,
      }
    ];
    
    for (const mix of sampleMixes) {
      this.createMix(mix);
    }
    
    // Seed gallery
    const sampleGallery: InsertGallery[] = [
      {
        imageUrl: "https://images.unsplash.com/photo-1571245287215-4788eca72323",
        caption: "Crowd going wild at our Amsterdam Dance Event special showcase",
        publishedAt: new Date("2023-10-20"),
        instagramUrl: "https://www.instagram.com/p/CxamplePost1/",
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1540039155733-5bb30b53aa14",
        caption: "DJ booth view during the Summer Festival Series",
        publishedAt: new Date("2023-08-05"),
        instagramUrl: "https://www.instagram.com/p/CxamplePost2/",
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1516638022313-53fa45a5fc5e",
        caption: "Spectacular light show at the Underground Sessions",
        publishedAt: new Date("2023-09-15"),
        instagramUrl: "https://www.instagram.com/p/CxamplePost3/",
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04",
        caption: "Behind the scenes with our production team",
        publishedAt: new Date("2023-07-30"),
        instagramUrl: "https://www.instagram.com/p/CxamplePost4/",
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1563841930606-67e2bce48b78",
        caption: "Charlotte de Witte mesmerizing the crowd at Warehouse Special",
        publishedAt: new Date("2023-11-12"),
        instagramUrl: "https://www.instagram.com/p/CxamplePost5/",
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1480563597043-1c877e682fc7",
        caption: "Sunset vibes at our Open Air event series",
        publishedAt: new Date("2023-06-21"),
        instagramUrl: "https://www.instagram.com/p/CxamplePost6/",
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1559654136-9f2e2d72419f",
        caption: "Laser show during the Techno Classics night",
        publishedAt: new Date("2023-08-28"),
        instagramUrl: "https://www.instagram.com/p/CxamplePost7/",
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1601974915460-b3dabfaf2b5b",
        caption: "Our livestream setup for the Global Sessions broadcast",
        publishedAt: new Date("2023-10-05"),
        instagramUrl: "https://www.instagram.com/p/CxamplePost8/",
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1598390594740-11c729a871f7",
        caption: "The crowd experiencing a magical moment during Ben Böhmer's live set",
        publishedAt: new Date("2023-11-30"),
        instagramUrl: "https://www.instagram.com/p/CxamplePost9/",
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1598387481401-a76a7aa15b74",
        caption: "Festival grounds at dusk before the night sessions begin",
        publishedAt: new Date("2023-07-15"),
        instagramUrl: "https://www.instagram.com/p/CxamplePost10/",
      }
    ];
    
    for (const item of sampleGallery) {
      this.createGalleryItem(item);
    }
  }
}

export const storage = new MemStorage();
