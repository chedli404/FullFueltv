import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertSubscriberSchema, 
  insertContactSchema 
} from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  const apiRouter = app.route('/api');
  
  // Videos routes
  app.get('/api/videos', async (req: Request, res: Response) => {
    try {
      const videos = await storage.getVideos();
      res.json(videos);
    } catch (error) {
      console.error('Error fetching videos:', error);
      res.status(500).json({ message: 'Failed to fetch videos' });
    }
  });
  
  app.get('/api/videos/featured', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
      const videos = await storage.getFeaturedVideos(limit);
      res.json(videos);
    } catch (error) {
      console.error('Error fetching featured videos:', error);
      res.status(500).json({ message: 'Failed to fetch featured videos' });
    }
  });
  
  app.get('/api/videos/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const video = await storage.getVideo(id);
      
      if (!video) {
        return res.status(404).json({ message: 'Video not found' });
      }
      
      res.json(video);
    } catch (error) {
      console.error('Error fetching video:', error);
      res.status(500).json({ message: 'Failed to fetch video' });
    }
  });
  
  // Events routes
  app.get('/api/events', async (req: Request, res: Response) => {
    try {
      const events = await storage.getEvents();
      res.json(events);
    } catch (error) {
      console.error('Error fetching events:', error);
      res.status(500).json({ message: 'Failed to fetch events' });
    }
  });
  
  app.get('/api/events/featured', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
      const events = await storage.getFeaturedEvents(limit);
      res.json(events);
    } catch (error) {
      console.error('Error fetching featured events:', error);
      res.status(500).json({ message: 'Failed to fetch featured events' });
    }
  });
  
  app.get('/api/events/upcoming', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
      const events = await storage.getUpcomingEvents(limit);
      res.json(events);
    } catch (error) {
      console.error('Error fetching upcoming events:', error);
      res.status(500).json({ message: 'Failed to fetch upcoming events' });
    }
  });
  
  app.get('/api/events/type/:type', async (req: Request, res: Response) => {
    try {
      const type = req.params.type;
      const events = await storage.getEventsByType(type);
      res.json(events);
    } catch (error) {
      console.error('Error fetching events by type:', error);
      res.status(500).json({ message: 'Failed to fetch events by type' });
    }
  });
  
  app.get('/api/events/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const event = await storage.getEvent(id);
      
      if (!event) {
        return res.status(404).json({ message: 'Event not found' });
      }
      
      res.json(event);
    } catch (error) {
      console.error('Error fetching event:', error);
      res.status(500).json({ message: 'Failed to fetch event' });
    }
  });
  
  // Mixes routes
  app.get('/api/mixes', async (req: Request, res: Response) => {
    try {
      const mixes = await storage.getMixes();
      res.json(mixes);
    } catch (error) {
      console.error('Error fetching mixes:', error);
      res.status(500).json({ message: 'Failed to fetch mixes' });
    }
  });
  
  app.get('/api/mixes/featured', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const mixes = await storage.getFeaturedMixes(limit);
      res.json(mixes);
    } catch (error) {
      console.error('Error fetching featured mixes:', error);
      res.status(500).json({ message: 'Failed to fetch featured mixes' });
    }
  });
  
  app.get('/api/mixes/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const mix = await storage.getMix(id);
      
      if (!mix) {
        return res.status(404).json({ message: 'Mix not found' });
      }
      
      res.json(mix);
    } catch (error) {
      console.error('Error fetching mix:', error);
      res.status(500).json({ message: 'Failed to fetch mix' });
    }
  });
  
  // Gallery routes
  app.get('/api/gallery', async (req: Request, res: Response) => {
    try {
      const gallery = await storage.getGalleryItems();
      res.json(gallery);
    } catch (error) {
      console.error('Error fetching gallery:', error);
      res.status(500).json({ message: 'Failed to fetch gallery' });
    }
  });
  
  app.get('/api/gallery/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getGalleryItem(id);
      
      if (!item) {
        return res.status(404).json({ message: 'Gallery item not found' });
      }
      
      res.json(item);
    } catch (error) {
      console.error('Error fetching gallery item:', error);
      res.status(500).json({ message: 'Failed to fetch gallery item' });
    }
  });
  
  // Newsletter subscription
  app.post('/api/subscribe', async (req: Request, res: Response) => {
    try {
      const result = insertSubscriberSchema.safeParse({
        ...req.body,
        subscribedAt: new Date()
      });
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      // Check if email already exists
      const existingSubscriber = await storage.getSubscriberByEmail(result.data.email);
      if (existingSubscriber) {
        return res.status(409).json({ message: 'Email already subscribed' });
      }
      
      const subscriber = await storage.createSubscriber(result.data);
      res.status(201).json(subscriber);
    } catch (error) {
      console.error('Error creating subscriber:', error);
      res.status(500).json({ message: 'Failed to create subscription' });
    }
  });
  
  // Contact form
  app.post('/api/contact', async (req: Request, res: Response) => {
    try {
      const result = insertContactSchema.safeParse({
        ...req.body,
        createdAt: new Date()
      });
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const contact = await storage.createContact(result.data);
      res.status(201).json(contact);
    } catch (error) {
      console.error('Error creating contact:', error);
      res.status(500).json({ message: 'Failed to submit contact form' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
